
<?php if (isset($component)) { $__componentOriginald3474b09374f7a1c6aabd4f89d6847dc = $component; } ?>
<?php $component = App\View\Components\PanelLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('panel-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\PanelLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <!--Main Navigation-->
<header>
    <!-- Sidebar -->
    <nav id="sidebarMenu" class="nav sidebar flex-column collapse d-lg-block bg-back">
      <div class="list-group list-group mx-3 mt-4">
        <a href="#" class=" list-group-item list-group-item-action py-2 ripple" id="item-home" aria-current="true">
          <i class="fa-solid fa-house fa-fw me-3"></i><span>Bienvenido</span>
        </a>
        
        <a href="<?php echo e(route('profile.edit')); ?>" class="list-group-item list-group-item-action py-2 ripple" id="item-profile" aria-current="true">
          <i class="fa-solid fa-address-card fa-fw me-3"></i><span>Mi Perfil</span>
        </a> 
      </div>
    </nav>

    <!-- Sidebar -->
  
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg bg-back fixed-top">
      <div class="container-fluid">
        <a  type="button" class="bg-back text-white me-3" data-bs-toggle="collapse" data-bs-target="#sidebarMenu" aria-controls="sidebarMenu" aria-expanded="false" aria-label="Toggle navigation">
          <i class="fa-solid fa-bars"></i>
        </a>
        <a class="navbar-brand text-white" href="#"><img src="/img/login/logo-negativo.png" alt="" class="img-fluid" style="max-width: 60px;"></a>
         <!-- Right links -->
        <ul class="navbar-nav ms-auto d-flex flex-row">
          <!-- Avatar -->
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle hidden-arrow d-flex align-items-center"  href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              <img
                  src="https://mdbootstrap.com/img/Photos/Avatars/img (31).jpg"
                  class="rounded-circle"
                  height="22"
                  alt=""
                  loading="lazy"
                  />
            </a>
            <ul
                class="dropdown-menu dropdown-menu-end"
                aria-labelledby="navbarDropdownMenuLink"
                >
              
              <li>
                <form  method="POST" action="<?php echo e(route('logout')); ?>">
                  <?php echo csrf_field(); ?>
                  <a href="<?php echo e(route('logout')); ?>" class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                  onclick="event.preventDefault();
                              this.closest('form').submit();">Logout</a>
                </form>
                
              
              </li>
            </ul>
          </li>
        </ul>
      </div>
    </nav>
    <!-- Navbar -->
</header>
  <!--Main Navigation-->
  
  <!--Main layout-->
  <main style="margin-top: 56px">

    <?php echo e($slot); ?>


  </main>



 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald3474b09374f7a1c6aabd4f89d6847dc)): ?>
<?php $component = $__componentOriginald3474b09374f7a1c6aabd4f89d6847dc; ?>
<?php unset($__componentOriginald3474b09374f7a1c6aabd4f89d6847dc); ?>
<?php endif; ?><?php /**PATH C:\Users\Jeft AC\Sistemas_Desarrollo\GitHub\ovn\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>
<section id="section3">
            <div class="row row-cols-1 row-cols-md-2" data-aos="fade-up" data-aos-delay="700">
                <div class="col">
                    <img src="/img/page/section3-2.png" class="img-fluid w-70" alt="">
                </div>
                <div class="col my-5 my-md-auto ps-5 ">
                        <h5 class="mx-auto my-0">Esto es Un titulo</h5>
                        <h1 class="mx-auto my-0 text-uppercase">Esto es Un titulo</h1>
                        <br>
                        <h5 class="mx-auto my-0">Esto es Un titulo</h5>
                        <p class="mx-auto mt-2 mb-5">
                            Lorem Ipsum es simplemente el texto de relleno de las <br>
                            imprentas y archivos de texto.
                        </p>
                        <a class="btn btn-green" href="#about">Conoce Mas</a>
                </div>
            </div>
</section><?php /**PATH C:\Users\Jeft AC\Sistemas_Desarrollo\GitHub\ovn\resources\views/page/home/section3.blade.php ENDPATH**/ ?>
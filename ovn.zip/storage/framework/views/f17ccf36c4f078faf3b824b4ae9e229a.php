
<section id="home">
        <div class="container px-4 px-lg-5 d-flex h-100 align-items-center justify-content-end">
            <div class="d-flex">
                <div class="text-end" data-aos="zoom-in-down">
                    <h1 class="mx-auto my-0 text-uppercase">Esto es Un titulo</h1>
                    <p class="mx-auto mt-2 mb-5">
                        Lorem Ipsum es simplemente el texto de relleno de las <br>
                        imprentas y archivos de texto.
                    </p>
                    <a class="btn btn-green" href="#about">Comprar</a>
                </div>
            </div>
        </div>
</section><?php /**PATH C:\Users\Jeft AC\Sistemas_Desarrollo\GitHub\ovn\resources\views/page/home.blade.php ENDPATH**/ ?>
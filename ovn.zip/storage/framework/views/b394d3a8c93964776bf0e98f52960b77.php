
<div class="card shadow rounded-0 m-md-5"> 
    <div class="card-header">
        <h4>INFORMACIÓN</h4>
        <p class="mt-1">
            <?php echo e(__("Actualice la información de perfil y la dirección de correo electrónico de su cuenta.")); ?>

        </p>
    </div>
    
    <div class="card-body">

        <form id="send-verification" method="post" action="<?php echo e(route('verification.send')); ?>">
            <?php echo csrf_field(); ?>
        </form>
        <form method="post" action="<?php echo e(route('profile.update')); ?>" class="mt-6 space-y-6">
            <?php echo csrf_field(); ?>
            <?php echo method_field('patch'); ?>

            
    
            <div>
                <label for="">Nombre</label>
                <input type="text" id="name" name="name" class="form-control mt-1 block w-full" value="<?php echo e(old('name', $user->name)); ?>" required autofocus autocomplete="name">
                <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['class' => 'mt-2','messages' => $errors->get('name')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mt-2','messages' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->get('name'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
            </div>
    
            <div>
                <label for="">Correo</label>
                <input type="text" id="email" name="email" class="form-control mt-1 block w-full" value="<?php echo e(old('email', $user->email)); ?>" required autofocus autocomplete="username">
                <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['class' => 'mt-2','messages' => $errors->get('email')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mt-2','messages' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->get('email'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
    
                <?php if($user instanceof \Illuminate\Contracts\Auth\MustVerifyEmail && ! $user->hasVerifiedEmail()): ?>
                    <div>
                        <p class="text-sm mt-2 ">
                            <?php echo e(__('Su dirección de correo electrónico no está verificada')); ?>

    
                            <button form="send-verification" class="underline text-sm ">
                                <?php echo e(__('Haga clic aquí para volver a enviar el correo electrónico de verificación.')); ?>

                            </button>
                        </p>
    
                        <?php if(session('status') === 'verification-link-sent'): ?>
                            <p class="mt-2 font-medium text-sm text-green-600 dark:text-green-400">
                                <?php echo e(__('Se ha enviado un nuevo enlace de verificación a su dirección de correo electrónico.')); ?>

                            </p>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>
            
                <button type='submit' class='btn btn-accept my-2'><?php echo e(__('Guardar')); ?></button>
    
               
        </form>
    </div>
    <?php if(session('status') === 'profile-updated'): ?>
            <div class="alert alert-success alert-dismissible fade show p-2 rounded-0" role="alert">
                <strong>Guardado Correctamente!</strong> 
                <button type="button" class="btn-close me-2 p-2" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
    <?php endif; ?>
</div><?php /**PATH C:\Users\Jeft AC\Sistemas_Desarrollo\GitHub\ovn\resources\views/profile/update-information.blade.php ENDPATH**/ ?>
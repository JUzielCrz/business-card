<section id="custom">
    <div class="container px-4 px-lg-5 d-flex h-100 align-items-center justify-content-start">
        <div class="d-flex" data-aos="fade-up" data-aos-delay="700">
            <div class="text-start"  >
                <h5 class="mx-auto my-0">Esto es Un titulo</h5>
                <h1 class="mx-auto my-0 text-uppercase">Esto es Un titulo</h1>
                <br>
                <h5 class="mx-auto my-0">Esto es Un titulo</h5>
                <p class="mx-auto mt-2 mb-5">
                    Lorem Ipsum es simplemente el texto de relleno de las <br>
                    imprentas y archivos de texto.
                </p>
                <a class="btn btn-green" href="#about">Comprar</a>
                <a class="btn btn-green" href="#about">Conoce Mas</a>
            </div>
        </div>
    </div>
</section><?php /**PATH C:\Users\Jeft AC\Sistemas_Desarrollo\GitHub\ovn\resources\views/page/home/custom.blade.php ENDPATH**/ ?>
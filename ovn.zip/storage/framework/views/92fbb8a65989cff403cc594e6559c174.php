<button <?php echo e($attributes->merge(['type' => 'submit', 'class' => 'btn  my-2'])); ?>>
    <?php echo e($slot); ?>

</button>
<?php /**PATH C:\Users\Jeft AC\Sistemas_Desarrollo\GitHub\ovn\resources\views/components/button-accept.blade.php ENDPATH**/ ?>
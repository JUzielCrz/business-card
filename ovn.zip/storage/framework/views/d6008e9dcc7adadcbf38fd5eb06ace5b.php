<div class="row barTop">
    <div class="col-md-6 justify-content-start align-items-center">
        <?php echo e($title); ?>

    </div>
    <div class="col-md-6 d-flex justify-content-end align-items-center">
        <?php echo e($slot); ?>

    </div>
    
</div>

<style>
    .barTop{
        margin: 0;
        padding: 15px;
        background-color: #676f9d;
        color: #ffff;
    }
    .btn-title{
        text-decoration: none;
        color: #ffffff;
        margin-inline: 5px;
        text-transform: uppercase;
    }
</style><?php /**PATH C:\Users\Jeft AC\Sistemas_Desarrollo\GitHub\ovn\resources\views/components/cardTitle.blade.php ENDPATH**/ ?>
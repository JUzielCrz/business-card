<?php if (isset($component)) { $__componentOriginal5f11a07a4ceb2a10b08382f3a19b4cf2 = $component; } ?>
<?php $component = App\View\Components\SidebarLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sidebar-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\SidebarLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <button type="button" class="btn btn-primary" >Hola esto es el panel</button>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5f11a07a4ceb2a10b08382f3a19b4cf2)): ?>
<?php $component = $__componentOriginal5f11a07a4ceb2a10b08382f3a19b4cf2; ?>
<?php unset($__componentOriginal5f11a07a4ceb2a10b08382f3a19b4cf2); ?>
<?php endif; ?><?php /**PATH C:\Users\Jeft AC\Sistemas_Desarrollo\GitHub\ovn\resources\views/panel/index.blade.php ENDPATH**/ ?>
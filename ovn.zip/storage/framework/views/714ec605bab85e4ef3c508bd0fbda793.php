<?php if (isset($component)) { $__componentOriginal5f11a07a4ceb2a10b08382f3a19b4cf2 = $component; } ?>
<?php $component = App\View\Components\SidebarLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sidebar-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\SidebarLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.cardTitle','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('cardTitle'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
             <?php $__env->slot('title', null, []); ?> Mi Perfil <?php $__env->endSlot(); ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
    <div class="container ">
                    <?php echo $__env->make('profile.update-information', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    <?php echo $__env->make('profile.update-password', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5f11a07a4ceb2a10b08382f3a19b4cf2)): ?>
<?php $component = $__componentOriginal5f11a07a4ceb2a10b08382f3a19b4cf2; ?>
<?php unset($__componentOriginal5f11a07a4ceb2a10b08382f3a19b4cf2); ?>
<?php endif; ?>

<script>
     $(document).ready(function(){
        $("#item-profile").addClass('active');

        $('#btn-current_password').click( (e) => { e.preventDefault(); showPassword("current_password", "#icon-current_password") });
        $('#btn-password').click((e) => {  e.preventDefault();  showPassword("password", "#icon-password");  });
        $('#btn-password_confirmation').click((e)=> { e.preventDefault(); showPassword("password_confirmation", "#icon-password_confirmation"); });

        function showPassword(idelement, icon_class){
        let cambio = document.getElementById(idelement);
		if(cambio.type == "password"){
			cambio.type = "text";
			$(icon_class).removeClass('fa-solid fa-eye-slash').addClass('fa-solid fa-eye');
		}else{
			cambio.type = "password";
			$(icon_class).removeClass('fa-solid fa-eye').addClass('fa-solid fa-eye-slash');
		}
	} 
    });
</script><?php /**PATH C:\Users\Jeft AC\Sistemas_Desarrollo\GitHub\ovn\resources\views/profile/edit.blade.php ENDPATH**/ ?>
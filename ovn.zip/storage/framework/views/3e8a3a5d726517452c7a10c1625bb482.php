<section id="section-cover">
    <div class="container">
        <div class="row p-5">
            <div class=" col text-center text-white pb-5" data-aos="zoom-in-down">
                <h1 class="text-uppercase mt-5">SERVICIOS</h1>
            </div>
        </div>
    </div>
</section><?php /**PATH C:\Users\Jeft AC\Sistemas_Desarrollo\GitHub\ovn\resources\views/page/services/cover.blade.php ENDPATH**/ ?>
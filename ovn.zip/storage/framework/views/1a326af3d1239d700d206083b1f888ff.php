<section id="about" >
    <div class="container ">
        <div class="row text-center">
            <div class="col">
                <h1>Esto es un titulo extendido de ejemplo<br> solo relleno  de texto y mas texto</h1>
                <p class="mt-4 mb-5"> Lorem ipsum dolor sit amet, consectetur adipiscing elit, <br> sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
            </div>
        </div>
        
        <div class="row row-cols-1 row-cols-md-3">
            <div class="col mb-3">
                <div class="card text-center" data-aos="fade-right" data-aos-delay="300">
                    <img src="/img/page/about-2.jpg" class="card-img-top" alt="...">
                    <div class="card-body">
                        <h3 class="my-4">Sample text</h3>
                        <p>Sample text. Click to select the Text Element.</p>
                    </div>
                </div>
            </div>
            <div class="col mb-3">
                <div class="card text-center" data-aos="fade-right" data-aos-delay="600">
                    <img src="/img/page/about-3.jpg" class="card-img-top" alt="...">
                    <div class="card-body">
                        <h3 class="my-4">Sample text</h3>
                        <p>Sample text. Click to select the Text Element.</p>
                    </div>
                </div>
            </div>
            <div class="col mb-3">
                <div class="card text-center" data-aos="fade-right" data-aos-delay="900">
                    <img src="/img/page/about-4.jpg" class="card-img-top"  alt="...">
                    <div class="card-body justify-content-center">
                        <h3 class="my-4">Sample text</h3>
                        <p>Sample text. Click to select the Text Element.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section><?php /**PATH C:\Users\Jeft AC\Sistemas_Desarrollo\GitHub\ovn\resources\views/page/home/about.blade.php ENDPATH**/ ?>
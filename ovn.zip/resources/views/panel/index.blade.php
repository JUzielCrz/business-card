<x-sidebar-layout>
    <button type="button" class="btn btn-primary" >Hola esto es el panel</button>
</x-sidebar-layout>

<x-panel-layout>
    <!--Main Navigation-->
<header>
    <!-- Sidebar -->
    <nav id="sidebarMenu" class="nav sidebar flex-column collapse d-lg-block bg-back">
      <div class="list-group list-group mx-3 mt-4">
        <a href="#" class=" list-group-item list-group-item-action py-2 ripple" id="item-home" aria-current="true">
          <i class="fa-solid fa-house fa-fw me-3"></i><span>Bienvenido</span>
        </a>
        {{-- <a href="#" class=" list-group-item list-group-item-action py-2 ripple" id="item-home" aria-current="true">
          <i class="fa-solid fa-house fa-fw me-3"></i><span>Mi catalogo</span>
        </a>
        <a href="{{route('products.index')}}" class="list-group-item list-group-item-action  py-2 ripple" id="item-products" aria-current="true">
          <i class="fa-solid fa-box fa-fw me-3"></i><span>Productos</span>
        </a>
        <a href="{{route('categories.index')}}" class="list-group-item  py-2 ripple" id="item-categories" aria-current="true">
          <i class="fa-solid fa-layer-group me-3"></i><span>Categorias</span>
        </a>
        <a href="{{route('comments.index')}}" class="list-group-item list-group-item-action py-2 ripple" id="item-comments" aria-current="true">
          <i class="fa-solid fa-message me-3"></i><span>Comentarios</span>
        </a>
        <a href="{{route('social.index')}}" class="list-group-item list-group-item-action py-2 ripple" id="item-social" aria-current="true">
          <i class="fa-solid fa-globe me-3"></i><span>Redes sociales</span>
        </a>
        <a href="{{route('company.index')}}" class="list-group-item list-group-item-action py-2 ripple" id="item-company" aria-current="true">
        <i class="fa-solid fa-building-user me-3"></i><span>Mis Empresas</span>
        </a>--}}
        <a href="{{ route('profile.edit') }}" class="list-group-item list-group-item-action py-2 ripple" id="item-profile" aria-current="true">
          <i class="fa-solid fa-address-card fa-fw me-3"></i><span>Mi Perfil</span>
        </a> 
      </div>
    </nav>

    <!-- Sidebar -->
  
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg bg-back fixed-top">
      <div class="container-fluid">
        <a  type="button" class="bg-back text-white me-3" data-bs-toggle="collapse" data-bs-target="#sidebarMenu" aria-controls="sidebarMenu" aria-expanded="false" aria-label="Toggle navigation">
          <i class="fa-solid fa-bars"></i>
        </a>
        <a class="navbar-brand text-white" href="#"><img src="/img/login/logo-negativo.png" alt="" class="img-fluid" style="max-width: 60px;"></a>
         <!-- Right links -->
        <ul class="navbar-nav ms-auto d-flex flex-row">
          <!-- Avatar -->
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle hidden-arrow d-flex align-items-center"  href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              <img
                  src="https://mdbootstrap.com/img/Photos/Avatars/img (31).jpg"
                  class="rounded-circle"
                  height="22"
                  alt=""
                  loading="lazy"
                  />
            </a>
            <ul
                class="dropdown-menu dropdown-menu-end"
                aria-labelledby="navbarDropdownMenuLink"
                >
              {{-- <li><a class="dropdown-item" href="{{ route('profile.edit') }}">Mi perfil</a></li> --}}
              <li>
                <form  method="POST" action="{{ route('logout') }}">
                  @csrf
                  <a href="{{route('logout')}}" class="dropdown-item" href="{{route('logout')}}"
                  onclick="event.preventDefault();
                              this.closest('form').submit();">Logout</a>
                </form>
                
              
              </li>
            </ul>
          </li>
        </ul>
      </div>
    </nav>
    <!-- Navbar -->
</header>
  <!--Main Navigation-->
  
  <!--Main layout-->
  <main style="margin-top: 56px">

    {{$slot}}

  </main>



</x-panel-layout>
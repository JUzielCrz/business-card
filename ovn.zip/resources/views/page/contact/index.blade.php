<link href="{{asset('css/page/contact.css')}}" rel="stylesheet">

<x-page-layout>

    {{-- Navbar --}}
    <x-page.navbar>
    </x-page.navbar>  


    @include('page.contact.cover')
    @include('page.contact.contact')
    @include('page.footer')
</x-page-layout>

<link href="{{asset('css/page/services.css')}}" rel="stylesheet">


<x-page-layout>

    {{-- Navbar --}}
    <x-page.navbar>
    </x-page.navbar>  



    @include('page.services.cover')
    @include('page.services.services')
    @include('page.footer')
</x-page-layout>

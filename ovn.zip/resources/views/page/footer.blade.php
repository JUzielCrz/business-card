<footer>
    <div class="row row row-cols-1 row-cols-md-3 ">
        <div class="col text-center ">
            <img src="/img/page/logo-negativo.png" alt="" class="img-fluid my-5" style="width: 200px">
        </div>
        <div class="col text-center text-md-start">
            <h5>CATEGORIAS</h5>
            <p>
                <a href="">Quiénes somos</a> <br>
                <a href="">Comparador de lentes progresivos</a> <br> 
                <a href="">Comparador de lentes visión sencilla</a> <br>
                <a href="">Comparador de tratamientos</a> <br>
                <a href="">Comparador de materiales</a> <br>
            </p>

               
        </div>

        <div class="col text-center text-md-start">
            <h5>REDES SOCIALES</h5>
            <a href=""><i class="fab fa-instagram fa-2x"></i></a> 
            <a href=""><i class="fab fa-twitter fa-2x"></i></a>     
            <a href=""><i class="fab fa-facebook-square fa-2x"></i></a>        
        </div>
    </div>

    <div class="row">
        <div class="col">
            
        </div>
    </div>
</footer>
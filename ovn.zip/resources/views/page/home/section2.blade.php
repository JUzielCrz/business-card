<section id="section2">
            <!-- About Start -->
        <div class="container-xxl py-5">
            <div class="container">
                <div class="row g-5 align-items-center">
                    <div class="col-lg-6" data-aos="fade-up" >
                        <h6 class="text-start text-green text-uppercase">About Us</h6>
                        <h1 class="mb-4">Welcome to <span class="text-green text-uppercase">OVN</span></h1>
                        <p class="mb-4">Tempor erat elitr rebum at clita. Diam dolor diam ipsum sit. Aliqu diam amet diam et eos. Clita erat ipsum et lorem et sit, sed stet lorem sit clita duo justo magna dolore erat amet</p>

                        <a class="btn btn-green py-3 px-5 mt-2" href="">Explore More</a>
                    </div>
                    <div class="col-lg-6">
                        <div class="row g-3">
                            <div class="col-6 text-end">
                                <img class="img-fluid rounded w-75" data-aos="zoom-in" data-aos-delay="100" src="img/page/section-1.jpg" style="margin-top: 25%;">
                            </div>
                            <div class="col-6 text-start">
                                <img class="img-fluid rounded w-100" data-aos="zoom-in" data-aos-delay="300" src="img/page/section-2.jpg">
                            </div>
                            <div class="col-6 text-end">
                                <img class="img-fluid rounded w-50" data-aos="zoom-in" data-aos-delay="500" src="img/page/section-3.jpg">
                            </div>
                            <div class="col-6 text-start">
                                <img class="img-fluid rounded w-75" data-aos="zoom-in" data-aos-delay="700" src="img/page/section-4.jpg">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- About End -->
</section>
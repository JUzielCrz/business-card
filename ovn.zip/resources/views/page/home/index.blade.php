<x-page-layout>

    {{-- Navbar --}}
    <x-page.navbar>
    </x-page.navbar>  

    @include('page.home.home')

    @include('page.home.section2')
    @include('page.home.section3')
    @include('page.home.about')

    @include('page.home.custom')


    @include('page.footer')
</x-page-layout>
